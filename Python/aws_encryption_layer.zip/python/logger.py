import logging
import json

class LogHandler(object):
    
    def __init__(self, event):
        self.event = event
        
    def create_log_handler(self):
        root = logging.getLogger()
        if root.handlers:
            for handler in root.handlers:
                root.removeHandler(handler)
        
      
        custom_dict = {'ContactId': self.event['Details']['ContactData']['ContactId']}
        logging.basicConfig(format=json.dumps({"Timestamp":
"%(asctime)s", "LogLevel": "%(levelname)s", "ContactId": "%(ContactId)s",
 "LineNumber": "%(lineno)s", "ModuleName":
"%(module)s", "FunctionName": "%(funcName)s", "Message": "%(message)s"}))
        logger = logging.getLogger(__name__)
        logger.setLevel(logging.DEBUG)
        
        
   
        

        lambda_logger = logging.LoggerAdapter(logger, custom_dict)
      
        return lambda_logger



class TaskAddingFilter(logging.Filter):
    def __init__(self):
        logging.Filter.__init__(self)
        
    def filter(self, record):
        record.args = record.args + ('ContactId') 
        